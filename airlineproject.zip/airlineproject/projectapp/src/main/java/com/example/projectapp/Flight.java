package com.example.projectapp;

import javafx.beans.property.*;

public class Flight {

    private final StringProperty flightID;
    private final StringProperty departureCity;
    private final StringProperty destinationCity;
    private final StringProperty flightClass;
    private final StringProperty date;
    private final DoubleProperty price;

    public Flight(String flightID, String departureCity, String destinationCity, String flightClass, String date, double price) {
        this.flightID = new SimpleStringProperty(flightID);
        this.departureCity = new SimpleStringProperty(departureCity);
        this.destinationCity = new SimpleStringProperty(destinationCity);
        this.flightClass = new SimpleStringProperty(flightClass);
        this.date = new SimpleStringProperty(date);
        this.price = new SimpleDoubleProperty(price);
    }

    public String getFlightID() {
        return flightID.get();
    }

    public void setFlightID(String flightID) {
        this.flightID.set(flightID);
    }

    public StringProperty flightIDProperty() {
        return flightID;
    }

    public String getDepartureCity() {
        return departureCity.get();
    }

    public void setDepartureCity(String departureCity) {
        this.departureCity.set(departureCity);
    }

    public StringProperty departureCityProperty() {
        return departureCity;
    }

    public String getDestinationCity() {
        return destinationCity.get();
    }

    public void setDestinationCity(String destinationCity) {
        this.destinationCity.set(destinationCity);
    }

    public StringProperty destinationCityProperty() {
        return destinationCity;
    }

    public String getFlightClass() {
        return flightClass.get();
    }

    public void setFlightClass(String flightClass) {
        this.flightClass.set(flightClass);
    }

    public StringProperty flightClassProperty() {
        return flightClass;
    }

    public String getDate() {
        return date.get();
    }

    public void setDate(String date) {
        this.date.set(date);
    }

    public StringProperty dateProperty() {
        return date;
    }

    public double getPrice() {
        return price.get();
    }

    public void setPrice(double price) {
        this.price.set(price);
    }

    public DoubleProperty priceProperty() {
        return price;
    }

    @Override
    public String toString() {
        return "Flight ID: " + flightID.get() +
                ", Departure: " + departureCity.get() +
                ", Destination: " + destinationCity.get() +
                ", Class: " + flightClass.get() +
                ", Date: " + date.get() +
                ", Price: $" + price.get();
}
}