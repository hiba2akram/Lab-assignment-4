package com.example.projectapp;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class NavigationHelper {

    private static boolean isLoggedIn = false;
    private static String loggedInUser = "";
    private static Stage parentStage;


    public static void openSignUpWindow(Stage parentStage) {

        Stage signUpStage = new Stage();
        VBox signUpBox = new VBox(15);
        signUpBox.setAlignment(Pos.CENTER);
        signUpBox.setPadding(new Insets(20));
        signUpBox.setStyle("-fx-background-color: #2c3e50;-fx-font-weight: bold;");

        TextField nameField = new TextField();
        nameField.setPromptText("Enter your name");
        nameField.setPrefHeight(40);
        nameField.setStyle("-fx-background-color: #3A3A3A; -fx-border-color: #1976D2; -fx-border-radius: 5px; -fx-text-fill: white; -fx-font-weight: bold;");

        TextField emailField = new TextField();
        emailField.setPromptText("Enter your email");
        emailField.setPrefHeight(40);
        emailField.setStyle("-fx-background-color: #3A3A3A; -fx-border-color: #1976D2; -fx-border-radius: 5px; -fx-text-fill: white; -fx-font-weight: bold;");
        Label signupLabel=new Label("Sign up");
        signupLabel.setFont(Font.font("Arial", 36));
        signupLabel.setStyle("-fx-text-fill: white;");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter your password");
        passwordField.setPrefHeight(40);
        passwordField.setStyle("-fx-background-color: #3A3A3A; -fx-border-color: #1976D2; -fx-border-radius: 5px; -fx-text-fill: white; -fx-font-weight: bold;");

        Button signUpButton = new Button("Sign Up");
        signUpButton.setPrefHeight(35);
        signUpButton.setStyle("-fx-background-color: #1976D2; -fx-text-fill: white; -fx-font-weight: bold;");
        signUpButton.setPrefWidth(100);
        signUpButton.setOnAction(e -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String password = passwordField.getText();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Validation Error", "Please fill in all fields.");
                return;
            }


            if (!email.matches("^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
                showAlert(Alert.AlertType.WARNING, "Invalid Email", "Please enter a valid email address.");
                return;
            }

            if (password.length() < 6) {
                showAlert(Alert.AlertType.WARNING, "Weak Password", "Password must be at least 6 characters long.");
                return;
            }

            if (UserFileHandler.emailExists(email)) {
                showAlert(Alert.AlertType.WARNING, "Email Already Registered", "This email is already registered.");
                return;
            }


            UserFileHandler.saveUserInfo(name, email, password);

            showAlert(Alert.AlertType.INFORMATION, "Sign-Up Successful", "You have successfully signed up!");
            signUpStage.close();
        });

        signUpBox.getChildren().addAll(signupLabel, nameField, emailField, passwordField, signUpButton);


        Scene signUpScene = new Scene(signUpBox, 400, 300);
        signUpStage.setTitle("Sign Up");
        signUpStage.setScene(signUpScene);
        signUpStage.show();
    }

    public static void openLoginWindow(Stage primaryStage) {
        Stage loginStage = new Stage();
        loginStage.setTitle("Login");

        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;-fx-background-color: #2c3e50;");
        Label loginLabel=new Label("Login to your account");
        loginLabel.setStyle("-fx-text-fill: white;-fx-text-fill: white;");
        loginLabel.setFont(Font.font("Arial", 20));
        TextField emailField = new TextField();
        emailField.setPromptText("Enter your email");
        emailField.setPrefHeight(35);
        emailField.setStyle("-fx-background-color: #3A3A3A; -fx-border-color: #1976D2; -fx-border-radius: 5px; -fx-text-fill: white; -fx-font-weight: bold;");

        PasswordField passwordField = new PasswordField();
        passwordField.setPrefHeight(35);
        passwordField.setPromptText("Enter your password");
        passwordField.setStyle("-fx-background-color: #3A3A3A; -fx-border-color: #1976D2; -fx-border-radius: 5px; -fx-text-fill: white; -fx-font-weight: bold;");


        Button loginButton = new Button("Login");
        loginButton.setPrefWidth(100);
        loginButton.setStyle("-fx-background-color: #1976D2; -fx-text-fill: white; -fx-font-weight: bold;");
        loginButton.setOnAction(e -> handleLogin(emailField.getText(), passwordField.getText(), loginStage));

        Button cancelButton = new Button("Cancel");
        cancelButton.setPrefWidth(100);
        Button forgotPassword= new Button("Forgot Password");
        forgotPassword.setOnAction(e->{
            NavigationHelper.openForgotPasswordWindow();
        });
        cancelButton.setStyle("-fx-background-color: #1976D2; -fx-text-fill: white;-fx-font-weight: bold;");
        cancelButton.setOnAction(e -> loginStage.close());
        forgotPassword.setStyle("-fx-background-color: red; -fx-text-fill: white;-fx-font-weight: bold;");

        layout.getChildren().addAll(loginLabel,
                emailField,
                passwordField,
                loginButton,
                cancelButton, forgotPassword
        );

        Scene loginScene = new Scene(layout, 400, 250);
        loginStage.setScene(loginScene);
        loginStage.show();
    }

    private static void handleLogin(String email, String password, Stage loginStage) {
        UserFileHandler userFileHandler = new UserFileHandler();

        if (userFileHandler.validateCredentials(email, password)) {
            isLoggedIn = true;
            loggedInUser = email;
            showAlert(Alert.AlertType.INFORMATION, "Login Success", "Welcome, " + email + "!");
            loginStage.close();
        } else {
            showAlert(Alert.AlertType.ERROR, "Login Failed", "Invalid email or password. Please try again.");
        }
    }

    public static void checkLoginBeforeAction(Runnable action) {
        if (!isLoggedIn) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Authentication Required");
            alert.setHeaderText(null);
            alert.setContentText("You need to log in to perform this action.");
            alert.showAndWait();
        } else {
            action.run();
        }
    }


    private static void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    public static void openPaymentInfoForm(Stage primaryStage) {
        Stage paymentStage = new Stage();
        paymentStage.setTitle("Payment Information");
        GridPane layout = new GridPane();
        layout.setStyle("-fx-background-color: #2c3e50;-fx-font-weight: bold;");
        layout.setAlignment(Pos.CENTER);
        layout.setVgap(15);
        layout.setHgap(15);
        layout.setPadding(new Insets(20));


        Label cardNumberLabel = new Label("Card Number:");
        cardNumberLabel.setTextFill(Color.WHITE);
        TextField cardNumberField = new TextField();
        cardNumberField.setPromptText("Enter your card number");
        cardNumberField.setStyle("-fx-background-color: #3A3A3A; -fx-border-color: #1976D2; -fx-border-radius: 5px; -fx-text-fill: white; -fx-font-weight: bold;");

        Label expiryDateLabel = new Label("Expiry Date (MM/YY):");
        expiryDateLabel.setTextFill(Color.WHITE);
        TextField expiryDateField = new TextField();
        expiryDateField.setPromptText("Enter expiry date");
        expiryDateField.setStyle("-fx-background-color: #3A3A3A; -fx-border-color: #1976D2; -fx-border-radius: 5px; -fx-text-fill: white; -fx-font-weight: bold;");

        Label cvvLabel = new Label("CVV:");
        cvvLabel.setTextFill(Color.WHITE);
        TextField cvvField = new TextField();
        cvvField.setPromptText("Enter CVV");
        cvvField.setStyle("-fx-background-color: #3A3A3A; -fx-border-color: #1976D2; -fx-border-radius: 5px; -fx-text-fill: white; -fx-font-weight: bold;");

        Button submitButton = new Button("Submit Payment Info");
        submitButton.setStyle("-fx-background-color: #1976D2; -fx-text-fill: white; -fx-font-weight: bold;");
        submitButton.setOnAction(e -> {
            String cardNumber = cardNumberField.getText();
            String expiryDate = expiryDateField.getText();
            String cvv = cvvField.getText();

            if (cardNumber.isEmpty() || expiryDate.isEmpty() || cvv.isEmpty()) {

                Alert alert = new Alert(Alert.AlertType.WARNING, "Please fill in all payment details.");
                alert.showAndWait();
            } else {

                UserFileHandler.savePaymentInfoToFile(cardNumber, expiryDate, cvv);
                paymentStage.close();
            }
        });


        Button cancelButton = new Button("Cancel");
        cancelButton.setStyle("-fx-background-color: #FF3D00; -fx-text-fill: white;");
        cancelButton.setOnAction(e -> paymentStage.close());


        layout.add(cardNumberLabel, 0, 0);
        layout.add(cardNumberField, 1, 0);
        layout.add(expiryDateLabel, 0, 1);
        layout.add(expiryDateField, 1, 1);
        layout.add(cvvLabel, 0, 2);
        layout.add(cvvField, 1, 2);
        layout.add(submitButton, 0, 3);
        layout.add(cancelButton, 1, 3);

        Scene scene = new Scene(layout, 400, 400);
        paymentStage.setScene(scene);
        paymentStage.show();

    }

    public static void openBookingConfirmationWindow(Stage primaryStage) {
    }

    public static void openForgotPasswordWindow() {
        Stage forgotStage = new Stage();
        forgotStage.setTitle("Forgot Password");

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-background-color: #2c3e50;-fx-font-weight: bold;");
        Label resetLabel=new Label("Reset your password");
        resetLabel.setStyle("-fx-text-fill: white;-fx-text-fill: white;");
        resetLabel.setFont(Font.font("Arial", 20));
        TextField emailField = new TextField();
        emailField.setPrefHeight(35);
        emailField.setStyle("-fx-border-radius: 5px;-fx-border-color: #1976D2;-fx-background-color: #3A3A3A;");
        emailField.setPromptText("Enter your registered email");

        PasswordField newPasswordField = new PasswordField();
        newPasswordField.setPrefHeight(35);
        newPasswordField.setPromptText("Enter new password");
        newPasswordField.setStyle("-fx-border-radius: 5px;-fx-border-color: #1976D2;-fx-background-color: #3A3A3A;");

        Button resetButton = new Button("Reset Password");
        resetButton.setStyle("-fx-background-color: #1976D2; -fx-text-fill: white; -fx-font-weight: bold;-fx-border-radius: 5px;");
        resetButton.setOnAction(e -> {
            String email = emailField.getText();
            String newPassword = newPasswordField.getText();

            if (email.isEmpty() || newPassword.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Validation Error", "Please fill in all fields.");
                return;
            }

            if (!newPassword.matches(".{6,}")) { // Simple password strength check
                showAlert(Alert.AlertType.WARNING, "Weak Password", "Password must be at least 6 characters long.");
                return;
            }

            if (UserFileHandler.resetPassword(email, newPassword)) {
                showAlert(Alert.AlertType.INFORMATION, "Password Reset", "Your password has been reset successfully.");
                forgotStage.close();
            } else {
                showAlert(Alert.AlertType.ERROR, "Reset Failed", "Email not found. Please try again.");
            }
        });

        Button cancelButton = new Button("Cancel");
        cancelButton.setPrefHeight(20);
        cancelButton.setPrefWidth(100);
        cancelButton.setStyle("-fx-background-color: #1976D2; -fx-text-fill: white; -fx-font-weight: bold;-fx-border-radius: 5px;");
        cancelButton.setOnAction(e -> forgotStage.close());

        layout.getChildren().addAll(resetLabel,
                emailField,
                newPasswordField,
                resetButton,
                cancelButton
        );

        Scene forgotScene = new Scene(layout, 350, 300);
        forgotStage.setScene(forgotScene);
        forgotStage.show();
}
}