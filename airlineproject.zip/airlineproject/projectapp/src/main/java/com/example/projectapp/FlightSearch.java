package com.example.projectapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.stream.Collectors;

public class FlightSearch {
    private static TableView<Flight> flightTable = new TableView<>(); // Initialize flightTable

    public static Flight getSelectedFlight() {
        return flightTable.getSelectionModel().getSelectedItem();
    }

    private static ObservableList<Flight> allFlights = FXCollections.observableArrayList(
            new Flight("FL123", "New York", "London", "Economy", "2024-12-15", 500),
            new Flight("FL124", "Los Angeles", "Paris", "Business", "2024-12-16", 1200),
            new Flight("FL125", "Chicago", "Tokyo", "Economy", "2024-12-20", 800),
            new Flight("FL126", "San Francisco", "Rome", "Business", "2024-12-22", 1500)
    );

    public static void openFlightSearchForm(Stage primaryStage) {
        Stage newStage = new Stage();
        newStage.setTitle("Flight Search");

        GridPane layout = createFlightSearchLayout(newStage);
        layout.setStyle("-fx-background-color: #2c3e50;-fx-font-weight: bold;");

        StackPane root = new StackPane();
        root.getChildren().add(layout);

        Scene scene = new Scene(root, 800, 700);
        primaryStage.setFullScreen(true);
        newStage.setScene(scene);
        newStage.show();
    }

    private static GridPane createFlightSearchLayout(Stage newStage) {
        GridPane layout = new GridPane();
        layout.setAlignment(Pos.CENTER);
        layout.setVgap(15);
        layout.setHgap(15);
        layout.setPadding(new Insets(20));

        Label flightSearchLabel = new Label("Flight Search");
        flightSearchLabel.setFont(new Font("Arial", 22));
        flightSearchLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");

        Label flightTypeLabel = new Label("Flight Type:");
        flightTypeLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        RadioButton oneWayRadio = new RadioButton("One-Way");
        RadioButton roundTripRadio = new RadioButton("Round-Trip");
        ToggleGroup flightTypeGroup = new ToggleGroup();
        oneWayRadio.setToggleGroup(flightTypeGroup);
        roundTripRadio.setToggleGroup(flightTypeGroup);
        oneWayRadio.setSelected(true);
        oneWayRadio.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        roundTripRadio.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");

        Label departureLabel = new Label("Departure City:");
        departureLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        TextField departureField = new TextField();
        departureField.setPromptText("Enter Departure City");

        Label destinationLabel = new Label("Destination City:");
        destinationLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        TextField destinationField = new TextField();
        destinationField.setPromptText("Enter Destination City");

        Label departureDateLabel = new Label("Departure Date:");
        departureDateLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        DatePicker departureDatePicker = new DatePicker();

        Label returnDateLabel = new Label("Return Date:");
        returnDateLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        DatePicker returnDatePicker = new DatePicker();
        returnDatePicker.setDisable(true);

        roundTripRadio.setOnAction(e -> returnDatePicker.setDisable(false));
        oneWayRadio.setOnAction(e -> returnDatePicker.setDisable(true));

        Label classLabel = new Label("Class:");
        classLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        ComboBox<String> classComboBox = new ComboBox<>();
        classComboBox.getItems().addAll("Economy", "Business");

        Label travelersLabel = new Label("Number of Travelers:");
        travelersLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");
        Spinner<Integer> travelersSpinner = new Spinner<>(1, 10, 1);

        flightTable = createFlightTable();

        Button searchButton = new Button("Search Flights");
        searchButton.setStyle("-fx-background-color: #4A90E2; -fx-text-fill: white;");
        searchButton.setOnAction(e -> handleSearchButtonClick(departureField, destinationField, classComboBox,
                departureDatePicker, returnDatePicker,
                flightTable, oneWayRadio, roundTripRadio));


        Button favoritesButton = new Button("Select Flight");
        favoritesButton.setStyle("-fx-background-color: #FFC107; -fx-text-fill: black;");
        favoritesButton.setOnAction(e -> saveSelectedFlight(flightTable.getSelectionModel().getSelectedItem()));


        Button cancelButton = new Button("Cancel");
        cancelButton.setStyle("-fx-background-color: #FF3D00; -fx-text-fill: white;");
        cancelButton.setOnAction(e -> newStage.close());

        layout.add(flightSearchLabel, 0, 0, 2, 1);
        layout.add(flightTypeLabel, 0, 1);
        layout.add(oneWayRadio, 1, 1);
        layout.add(roundTripRadio, 1, 2);
        layout.add(departureLabel, 0, 3);
        layout.add(departureField, 1, 3);
        layout.add(destinationLabel, 0, 4);
        layout.add(destinationField, 1, 4);
        layout.add(departureDateLabel, 0, 5);
        layout.add(departureDatePicker, 1, 5);
        layout.add(returnDateLabel, 0, 6);
        layout.add(returnDatePicker, 1, 6);
        layout.add(travelersLabel, 0, 7);
        layout.add(travelersSpinner, 1, 7);
        layout.add(classLabel, 0, 8);
        layout.add(classComboBox, 1, 8);
        layout.add(flightTable, 0, 9, 2, 1);
        layout.add(searchButton, 0, 10);
        layout.add(favoritesButton, 1, 10);
        layout.add(cancelButton, 1, 11);

        return layout;
    }

    private static TableView<Flight> createFlightTable() {
        TableView<Flight> table = new TableView<>();
        table.setPrefWidth(600);

        TableColumn<Flight, String> flightIDColumn = new TableColumn<>("Flight ID");
        flightIDColumn.setCellValueFactory(cellData -> cellData.getValue().flightIDProperty());

        TableColumn<Flight, String> departureCityColumn = new TableColumn<>("Departure City");
        departureCityColumn.setCellValueFactory(cellData -> cellData.getValue().departureCityProperty());

        TableColumn<Flight, String> destinationCityColumn = new TableColumn<>("Destination City");
        destinationCityColumn.setCellValueFactory(cellData -> cellData.getValue().destinationCityProperty());

        TableColumn<Flight, String> flightClassColumn = new TableColumn<>("Class");
        flightClassColumn.setCellValueFactory(cellData -> cellData.getValue().flightClassProperty());

        TableColumn<Flight, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setCellValueFactory(cellData -> cellData.getValue().dateProperty());

        TableColumn<Flight, Double> priceColumn = new TableColumn<>("Price (PKR)");
        priceColumn.setCellValueFactory(cellData -> cellData.getValue().priceProperty().asObject());

        table.getColumns().addAll(flightIDColumn, departureCityColumn, destinationCityColumn, flightClassColumn, dateColumn, priceColumn);
        table.setItems(allFlights);

        return table;
    }

    private static void handleSearchButtonClick(TextField departureField, TextField destinationField,
                                                ComboBox<String> classComboBox, DatePicker departureDatePicker,
                                                DatePicker returnDatePicker, TableView<Flight> flightTable,
                                                RadioButton oneWayRadio, RadioButton roundTripRadio) {
        String departure = departureField.getText();
        String destination = destinationField.getText();
        String selectedClass = classComboBox.getValue();
        LocalDate departureDate = departureDatePicker.getValue();
        LocalDate returnDate = returnDatePicker.getValue();

        if (departure.isEmpty() || destination.isEmpty() || selectedClass == null || departureDate == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please fill all required fields.");
            alert.showAndWait();
            return;
        }

        if (roundTripRadio.isSelected() && returnDate == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a return date for Round-Trip flights.");
            alert.showAndWait();
            return;
        }

        ObservableList<Flight> filteredFlights = allFlights.stream()
                .filter(flight -> flight.getDepartureCity().equalsIgnoreCase(departure))
                .filter(flight -> flight.getDestinationCity().equalsIgnoreCase(destination))
                .filter(flight -> flight.getFlightClass().equalsIgnoreCase(selectedClass))
                .filter(flight -> flight.getDate().equals(departureDate.toString()) ||
                        (roundTripRadio.isSelected() && flight.getDate().equals(returnDate.toString())))
                .collect(Collectors.toCollection(FXCollections::observableArrayList));

        if (filteredFlights.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "No flights match the search criteria.");
            alert.showAndWait();
        } else {
            flightTable.setItems(filteredFlights);
        }
    }

    private static void saveSelectedFlight(Flight selectedFlight) {
        if (selectedFlight == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Please select a flight to save.");
            alert.showAndWait();
            return;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("favorites.txt", true))) {
            writer.write(selectedFlight.toString());
            writer.newLine();
            Alert alert = new Alert(Alert.AlertType.INFORMATION, "Your Flight is saved.");
            alert.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
 }
}
}